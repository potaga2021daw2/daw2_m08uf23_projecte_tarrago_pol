<html>
	<head>
		<title>
			MENÚ PRINCIPAL 
		</title>
	</head>
	<body>
		<h2> MENÚ PRINCIPAL DE L'APLICACIÓ D'ACCÉS</h2>
		<h3> <b>Fet per: Pol Tarragó Gargallo</b> </h3>
		<a href="http://zend-potaga.fjeclot.net/proyecto_PolTarrago/visualitzar.php">Visualitzar usuaris</a><br>
		<a href="http://zend-potaga.fjeclot.net/proyecto_PolTarrago/afegir.php">Afegir usuaris</a><br>
		<a href="http://zend-potaga.fjeclot.net/proyecto_PolTarrago/modificar.php">Modificar usuaris</a><br>
		<a href="http://zend-potaga.fjeclot.net/proyecto_PolTarrago/esborrar.php">Esborrar usuaris</a><br>
		
	</body>
</html>
