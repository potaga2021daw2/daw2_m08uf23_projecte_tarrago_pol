<html>
	<head>
		<title>
			LOGIN
		</title>
	</head>
	<body>
		<h3>Inicia sessió:</h3>
		<form action="http://zend-potaga.fjeclot.net/proyecto_PolTarrago/auth.php" method="POST">
			Usuari: <input type="text" name="adm"><br>
			Contrasenya: <input type="password" name="cts"><br>
			<input type="submit" value="Envia" />
			<input type="reset" value="Neteja" />
		</form>
	</body>
</html>
